"""Bellhaven local review app. Real CRM changes require an explicit reviewer click."""
import csv
import os
from pathlib import Path
import pandas as pd
import streamlit as st
from crm_client import CRMClient, apply_approved
from review_engine import (build_proposals, build_site_proposal, clean_websites,
                           open_db, reviewed_keys, status_rows, store_decision, s)
from scraper import scrape_all, save_csv

ROOT = Path(__file__).resolve().parent
SITE_FILE = ROOT / "bellhaven_locations.csv"
CRM_FILE = ROOT / "bellhaven_crm_accounts.csv"
DB_FILE = ROOT / "data" / "review.sqlite"

st.set_page_config(page_title="Bellhaven CRM Reconciliation", layout="wide")
st.title("Bellhaven · Location / CRM Review")
st.caption("Website evidence → candidate matching → human approval → authenticated CRM API write")
st.info("No CRM writes happen during scraping, matching, reloading, or rejecting. Only the explicit 'Approve & apply' button can change CRM data.")

with st.sidebar:
    st.header("Sources")
    st.caption("The API token stays in this browser session; it is not written to a file or included in the ZIP.")
    token = st.text_input("Personal CRM API token", type="password", value=os.environ.get("BELLHAVEN_CRM_TOKEN", ""))
    if st.button("Connect / refresh LIVE CRM", use_container_width=True):
        try:
            accounts = CRMClient(token).list_accounts()
            st.session_state.crm_accounts = accounts
            st.session_state.crm_live = True
            st.success(f"Connected: {len(accounts)} accounts")
        except Exception as exc:
            st.error(f"CRM read failed: {exc}")
    if st.button("Scrape LIVE website (read only)", use_container_width=True):
        try:
            with st.spinner("Reading public facility pages..."):
                locations = scrape_all()
                save_csv(locations, SITE_FILE)
            st.success(f"Saved {len(locations)} public facilities")
        except Exception as exc:
            st.error(f"Scrape failed; bundled CSV remains unchanged. {exc}")
    if st.button("Use bundled CRM snapshot (offline)", use_container_width=True):
        st.session_state.pop("crm_accounts", None)
        st.session_state.crm_live = False
    st.divider()
    st.markdown("**How approvals work**")
    st.caption("Review each proposal and its website URL. Reject records a local decision. Approve applies only the selected proposal, then verifies the new CRM state.")
    st.caption("CHOW safety: revenue > 0 AND outstanding A/R > 0 means create a new Bellhaven account and link old.chow_current_account, without editing any other old field.")

try:
    if not SITE_FILE.exists() or not CRM_FILE.exists():
        st.error("Required CSV is missing. Keep bellhaven_locations.csv and bellhaven_crm_accounts.csv beside app.py.")
        st.stop()
    websites = clean_websites(pd.read_csv(SITE_FILE, dtype=str).fillna("").to_dict("records"))
    if "crm_accounts" in st.session_state:
        accounts = st.session_state.crm_accounts
        live = bool(st.session_state.get("crm_live"))
    else:
        accounts = pd.read_csv(CRM_FILE, dtype=str).fillna("").to_dict("records")
        live = False
    proposals, parent_id = build_proposals(websites, accounts)
except Exception as exc:
    st.error(f"Could not load reconciliation: {exc}")
    st.stop()

conn = open_db(DB_FILE)
decided = reviewed_keys(conn)
pending = [p for p in proposals if p["action"] != "none" and p["key"] not in decided]

cols = st.columns(4)
cols[0].metric("Website locations", len(websites))
cols[1].metric("CRM accounts", len(accounts))
cols[2].metric("Changes to review", len(pending))
cols[3].metric("Decisions saved", len(decided))
if not live:
    st.warning("OFFLINE preview: you are viewing the bundled CRM CSV. Connect to the LIVE CRM in the sidebar before approving any write.")
else:
    st.success("LIVE CRM connected. Only reviewer-approved actions will be written.")

st.subheader("Audit overview")
overview = []
for p in proposals:
    rec = p.get("account") or {}
    site = p.get("site") or {}
    overview.append({
        "status": "Decided" if p["key"] in decided else ("No change" if p["action"] == "none" else "Pending"),
        "classification": p["classification"], "website": site.get("name", ""),
        "crm": rec.get("name", ""), "crm_id": rec.get("account_id", ""),
        "action": p["action"], "score": p.get("score", 0), "reason": p.get("evidence", ""),
    })
overview_df = pd.DataFrame(overview)
st.dataframe(overview_df, hide_index=True, use_container_width=True)
st.download_button("Download matching findings CSV", overview_df.to_csv(index=False), "bellhaven_matching_findings.csv", "text/csv")

st.subheader("Review one proposal")
if not pending:
    st.success("There are no undecided proposed changes in this saved review queue.")
else:
    def label(p):
        name = (p.get("site") or {}).get("name") or (p.get("account") or {}).get("name") or "Unknown"
        return f"{p['classification']} · {name} · {p['action']}"
    chosen_index = st.selectbox("Select a pending proposal", range(len(pending)), format_func=lambda i: label(pending[i]))
    proposal = pending[chosen_index]
    site = proposal.get("site") or {}
    account = proposal.get("account") or {}
    if site:
        st.markdown(f"**Website:** {site.get('name')} — {site.get('address')}, {site.get('city')}, {site.get('state')} {site.get('zip')}")
        st.write("Care offerings:", site.get("care_offerings"))
        st.write("Source:", site.get("source_url"))
    if account:
        st.markdown(f"**CRM:** {account.get('name')} — ID `{account.get('account_id')}`")
        st.write(f"Address: {account.get('billing_street')}, {account.get('billing_city')}, {account.get('billing_state')} {account.get('billing_zip')}")
        st.write(f"Parent: {account.get('parent_name')} · Revenue: {account.get('lifetime_revenue')} · Outstanding A/R: {account.get('outstanding_ar')}")
    if proposal.get("kind") == "duplicate":
        survivor = proposal["survivor"]
        st.warning(f"Potential duplicate: proposed survivor ID is {survivor['account_id']} ({survivor['name']}). Verify before approval.")
    st.write("**Matching evidence:**", proposal.get("evidence"))

    # Never silently choose among several plausible CRM identities.
    if proposal["action"] == "investigate":
        alternatives = proposal.get("alternatives", [])
        pick_options = ["Select an account (required)", "None is correct — create a new account"]
        pick_options += [f"{x['account']['account_id']} — {x['account']['name']} — {x['account'].get('parent_name','')} — score {x['score']}" for x in alternatives]
        pick = st.selectbox("Choose the correct CRM identity after comparing evidence", pick_options,
                            key="candidate_" + proposal["key"])
        if pick == pick_options[1]:
            proposal = build_site_proposal(site, None, parent_id, alternatives=alternatives,
                                           evidence="Reviewer explicitly found no existing CRM account among candidates")
        elif pick not in (pick_options[0], pick_options[1]):
            index = pick_options.index(pick) - 2
            selected = alternatives[index]
            proposal = build_site_proposal(site, selected["account"], parent_id,
                                           alternatives=alternatives, score=selected["score"], evidence=selected["reason"])
        else:
            st.warning("Choose a CRM account or explicitly select 'create new' before approving. Reject is still available.")
    st.markdown("**Proposed action:** " + proposal.get("summary", ""))
    if proposal.get("changes"):
        st.json(proposal["changes"])
    note = st.text_area("Reviewer explanation (recommended)", key="review_note_" + proposal["key"],
                        placeholder="Why does website evidence support this decision?")
    confirm = st.checkbox("I compared the supporting evidence and approve this exact action.",
                          key="confirm_" + proposal["key"])
    left, right = st.columns(2)
    with left:
        if st.button("Reject proposal (no CRM write)", type="secondary", use_container_width=True):
            store_decision(conn, proposal["key"], "Rejected", note or "Reviewer rejected the suggested change", proposal)
            st.success("Rejected and saved locally. Reruns will not re-propose this item.")
            st.rerun()
    with right:
        allowed = confirm and proposal["action"] not in ("investigate",)
        if proposal["action"] != "none":
            allowed = allowed and live and bool(token)
        if st.button("Approve & apply selected action to CRM" if proposal["action"] != "none" else "Mark reviewed — no change",
                     type="primary", disabled=not allowed, use_container_width=True):
            try:
                client = CRMClient(token) if proposal["action"] != "none" else None
                with st.spinner("Applying this reviewer-approved change..."):
                    if proposal["action"] == "none":
                        store_decision(conn, proposal["key"], "Reviewed — no change", note, proposal)
                        result = "Reviewed; no change required."
                    else:
                        result = apply_approved(client, conn, proposal, parent_id)
                        st.session_state.crm_accounts = client.list_accounts()
                        st.session_state.crm_live = True
                st.success(result)
                st.rerun()
            except Exception as exc:
                st.error(f"CRM update was not confirmed: {exc}. Inspect CRM before retrying.")

st.subheader("Decision history (persistent)")
history = status_rows(conn)
if history:
    history_df = pd.DataFrame(history, columns=["proposal_key", "decision", "explanation", "when_utc"])
    st.dataframe(history_df, hide_index=True, use_container_width=True)
    st.download_button("Download decision audit CSV", history_df.to_csv(index=False),
                       "bellhaven_decisions.csv", "text/csv")
else:
    st.caption("No approvals or rejections yet. Decisions will be saved in data/review.sqlite.")
st.caption("After approving a CRM change, open Bellhaven's read-only CRM browser and verify the updated record. For the demo, show an approval and a rejection.")
